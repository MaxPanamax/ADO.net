﻿namespace ConsoleApp1.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class DataAnnotations : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Games", "NameGame", c => c.String(nullable: false, maxLength: 1000));
            AlterColumn("dbo.Games", "StudioGame", c => c.String(maxLength: 256));
            AlterColumn("dbo.Games", "StyleGame", c => c.String(maxLength: 256));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Games", "StyleGame", c => c.String());
            AlterColumn("dbo.Games", "StudioGame", c => c.String());
            AlterColumn("dbo.Games", "NameGame", c => c.String());
        }
    }
}
