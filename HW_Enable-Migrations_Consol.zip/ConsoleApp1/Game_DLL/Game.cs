﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1.Game_DLL
{
    public class Game
    {
        public int GameId { get; set; }
        [MaxLength(1000)]
        [Required]
        public string NameGame { get; set; }
        [MaxLength(256)]
        public string StudioGame { get; set; }
        [MaxLength(256)]
        public string StyleGame { get; set; }
        
        public DateTime DateRelis { get; set; }
        public decimal PriceGame { get; set; }
        
    }
}
