﻿using ConsoleApp1.Game_DLL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            using (Model1 model = new Model1())
            {
                Game game = new Game();
                game.NameGame = "Tanks";
                game.StudioGame = "Maximus";
                game.StyleGame = "Arcada";
                game.DateRelis = Convert.ToDateTime("2023.11.06");
                game.PriceGame = Convert.ToDecimal("120,0");

                model.Games.Add(game);
                model.SaveChanges();
            }
        }
    }
}
