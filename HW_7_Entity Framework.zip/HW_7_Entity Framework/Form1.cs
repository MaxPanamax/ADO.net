﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HW_7_Entity_Framework
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            var defaultBackColor = button1.BackColor;
            button1.GotFocus += (sender, args) => { button1.BackColor = Color.Red; };
            button1.LostFocus += (sender, args) => { button1.BackColor = defaultBackColor; };
            if (textBox1.Text.Length == 0)
            {
                button1.Enabled = false;
            }
            button1.Enabled=true;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            foreach (var item in this.Controls.OfType<TextBox>())
            {
                item.TextChanged += textBox1_TextChanged;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            using (Library2Entities dblib=new Library2Entities())
            {
                dblib.Configuration.LazyLoadingEnabled = false;
                var author = (from b in dblib.Authors
                              where (b.Lastname.StartsWith(textBox1.Text))
                              select b).FirstOrDefault<Authors>();
                dblib.Entry(author).Collection("Book").Load();
      
                dataGridView1.DataSource=dblib.Book.Select(book=>new 
                { book.Title, book.Price, author.FirstName, author.Lastname }).ToList();
                 
            }
        }

        private void button1_TextChanged(object sender, EventArgs e)
        {
            button1.Enabled = this.Controls.OfType<TextBox>().All(x => x.Text.Length > 0);

        }
    }
}
