﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//Домашнее задание
//Создайте Windows Forms приложение для работы с нашей БД с использованием Entity Framework по технологии 
//Database First. В главном окне приложения должен содержаться элемент TabControl с тремя вкладками: Books, 
//Authors и Publishers. Каждая вкладка должна обслуживать одну из таблиц нашей БД и выполнять добавление,
//удаление и редактирование записей в своей таблице.
//Для добавления, редактирования и удаления записей 
//использовать формы. Для отображения результатов методов GetAllAuthors(),GetAllBooks() и GetAllPublishers()
//использовать DataGridView.


namespace HW_6_end
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 0)
            {
                dataGridView4.DataSource = null;
                dataGridView4.DataSource = dataGridView1.DataSource;
            }
            if (tabControl1.SelectedIndex == 1)
            {
                dataGridView4.DataSource = null;
                dataGridView4.DataSource = dataGridView2.DataSource;
            }
            if (tabControl1.SelectedIndex == 2)
            {
                dataGridView4.DataSource = null;
                dataGridView4.DataSource = dataGridView3.DataSource;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "Book" || textBox1.Text == "Author" || textBox1.Text == "Publisher")
            {
                if (textBox1.Text == "Book")
                {
                    using (Library2Entities db = new Library2Entities())
                    {

                        var bk = (from c in db.Book
                                  select new
                                  {
                                      Id = c.id,
                                      Title = c.Title,
                                      IdAuthor = c.idAuthors,
                                      Pages = c.Pages,
                                      Price = c.Price,
                                      IdPublisher = c.idPublisher,
                                  }).ToList();
                        dataGridView1.DataSource = null;
                        dataGridView1.DataSource = bk;
                    }
                }
                if (textBox1.Text == "Author")
                {
                    using (Library2Entities db = new Library2Entities())
                    {

                        var bk = (from c in db.Authors
                                  select new
                                  {
                                      Id = c.id,
                                      FirstName = c.FirstName,
                                      LastName = c.Lastname
                                  }).ToList();
                        dataGridView2.DataSource = null;
                        dataGridView2.DataSource = bk;
                    }
                }
                if (textBox1.Text == "Publisher")
                {
                    using (Library2Entities db = new Library2Entities())
                    {

                        var bk = (from c in db.Publisher
                                  select new
                                  {
                                      Id = c.id,
                                      PublisherName = c.PublisherName,
                                      Address = c.Adderss,
                                  }).ToList();
                        dataGridView3.DataSource = null;
                        dataGridView3.DataSource = bk;
                    }
                }
            }
            else
            {
                MessageBox.Show("Неправильное имя таблицы");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Library2Entities dblib = new Library2Entities();
            if (tabControl1.SelectedIndex == 0)
            {
                if(dataGridView1.SelectedRows.Count>0)
                {
                    int index = dataGridView1.SelectedRows[0].Index;
                    int id = 0;
                    bool convert = Int32.TryParse(dataGridView1[0, index].Value.ToString(),out id);
                    if(convert==false)
                    { return; }
                    Book db = dblib.Book.Find(id);
                    Form2 book = new Form2();
                    book.textBox1.Text=db.Title;
                    book.textBox2.Text = Convert.ToString(db.idAuthors);
                    book.textBox3.Text = Convert.ToString(db.Pages);
                    book.textBox4.Text = Convert.ToString(db.Price);
                    book.textBox5.Text = Convert.ToString(db.idPublisher);

                    DialogResult result = book.ShowDialog();
                    if(result==DialogResult.Cancel)
                    {
                        return;
                    }
                    db.Title = book.textBox1.Text;
                    db.idAuthors = Convert.ToInt32(book.textBox2.Text);
                    db.Pages = Convert.ToInt32(book.textBox3.Text);
                    db.Price = Convert.ToInt32(book.textBox4.Text);
                    db.idPublisher = Convert.ToInt32(book.textBox5.Text);
                    dblib.SaveChanges();
                    dataGridView1.Refresh();
                    MessageBox.Show("обновление книг произошло");
                }
            }
            if (tabControl1.SelectedIndex == 1)
            {
                if(dataGridView2.SelectedRows.Count > 0)
                {
                    int index = dataGridView2.SelectedRows[0].Index;
                    int id = 0;
                    bool convert = Int32.TryParse(dataGridView2[0, index].Value.ToString(), out id);
                    if (convert == false) { return; }
                    Authors db = dblib.Authors.Find(id);
                    Form3 author = new Form3();
                    author.textBox1.Text = db.FirstName;
                    author.textBox2.Text = db.Lastname;
                    DialogResult result = author.ShowDialog();
                    if(result==DialogResult.Cancel)
                    { return; }
                    db.FirstName = author.textBox1.Text;
                    db.Lastname = author.textBox2.Text;
                    dblib.SaveChanges();
                    dataGridView2.Refresh();
                    MessageBox.Show("обновление авторов произошло");
                }
            }
            if (tabControl1.SelectedIndex == 2)
            {
                if(dataGridView3.SelectedRows.Count>0)
                {
                    int index= dataGridView3.SelectedRows[0].Index; int id = 0;
                    bool convert = Int32.TryParse(dataGridView3[0, index].Value.ToString(), out id);
                    if (convert == false) { return; }
                    Publisher db = dblib.Publisher.Find(id);
                    Form4 publish = new Form4();
                    publish.textBox1.Text = db.PublisherName;
                    publish.textBox2.Text = db.Adderss;
                    DialogResult result = publish.ShowDialog();
                    if (result == DialogResult.Cancel) { return; }
                    db.PublisherName = publish.textBox1.Text;
                    db.Adderss = publish.textBox2.Text;
                    dblib.SaveChanges();
                    dataGridView3.Refresh();
                    MessageBox.Show("обновление издателей произошло");
                } 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Library2Entities dblib = new Library2Entities();
            if (tabControl1.SelectedIndex == 0)
            {   
                 Form2 book = new Form2();
                 DialogResult result = book.ShowDialog(this);
                 if (result == DialogResult.Cancel)
                 {
                     return;
                 }
                 Book db = new Book();
                 db.Title = book.textBox1.Text;
                 db.idAuthors = Convert.ToInt32(book.textBox2.Text);
                 db.Pages = Convert.ToInt32(book.textBox3.Text);
                 db.Price = Convert.ToInt32(book.textBox4.Text);
                 db.idPublisher = Convert.ToInt32(book.textBox5.Text);

                 dblib.Book.Add(db);
                 dblib.SaveChanges();
                dataGridView1.Refresh();
                MessageBox.Show("новая книга добавлена");
            }
            if (tabControl1.SelectedIndex == 1)
            {
                Form3 Author = new Form3();
                DialogResult result = Author.ShowDialog(this);
                if(result==DialogResult.Cancel)
                {
                    return;
                }
                Authors db = new Authors();
                db.FirstName=Author.textBox1.Text;
                db.Lastname =Author.textBox2.Text;

                dblib.Authors.Add(db);
                dblib.SaveChanges();
                dataGridView2.Refresh();
                MessageBox.Show("новый автор добавлен");
            }
            if (tabControl1.SelectedIndex == 2)
            {
                Form4 Publish = new Form4();
                DialogResult result = Publish.ShowDialog(this);
                if(result==DialogResult.Cancel)
                {
                    return;
                }
                Publisher db = new Publisher();
                db.PublisherName =Publish.textBox1.Text;
                db.Adderss=Publish.textBox2.Text;

                dblib.Publisher.Add(db);
                dblib.SaveChanges();
                dataGridView3.Refresh();
                MessageBox.Show("новый издатель добавлен");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Library2Entities dblib = new Library2Entities();
            if (tabControl1.SelectedIndex == 0)
            {
                if(dataGridView1.SelectedRows.Count>0)
                {
                    int index = dataGridView1.SelectedRows[0].Index;
                    int id = 0;
                    bool convert = Int32.TryParse(dataGridView1[0, index].Value.ToString(), out id);
                    if (convert == false) { return; }
                    Book db = dblib.Book.Find(id);
                    dblib.Book.Remove(db);
                    dblib.SaveChanges();
                    dataGridView1.Refresh();
                    MessageBox.Show("удаление книги прозошло");
                 
                }
            }
            if (tabControl1.SelectedIndex == 1)
            {
                if(dataGridView2.SelectedRows.Count>0)
                {
                    int index = dataGridView2.SelectedRows[0].Index;
                    int id = 0;
                    bool convert = Int32.TryParse(dataGridView2[0, index].Value.ToString(), out id);
                    if(convert==false) { return; }
                    Authors db = dblib.Authors.Find(id);
                    dblib.Authors.Remove(db);
                    dblib.SaveChanges();
                    dataGridView2.Refresh();
                    MessageBox.Show("удаление автора произошло");
                }
            }
            if (tabControl1.SelectedIndex == 2)
            {
                if(dataGridView3.SelectedRows.Count>0)
                {
                    int index = dataGridView3.SelectedRows[0].Index;
                    int id = 0;
                    bool convert = Int32.TryParse(dataGridView3[0, index].Value.ToString(), out id);
                    if (convert == false) { return; }
                    Publisher db = dblib.Publisher.Find(id);
                    dblib.Publisher.Remove(db);
                    dblib.SaveChanges();
                    dataGridView3.Refresh();
                    MessageBox.Show("удоление издателя произошло");
                }
            }
        }
    }
}
